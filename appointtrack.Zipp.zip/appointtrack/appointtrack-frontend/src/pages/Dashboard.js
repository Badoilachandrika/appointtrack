import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Dashboard() {
  const [appointments, setAppointments] = useState([]);
  const navigate = useNavigate();
  const userId = localStorage.getItem("userId");

  const fetchAppointments = async () => {
    if (!userId) return;
    try {
      const res = await axios.get('http://localhost:5000/api/appointments?userId=${userId}');
      console.log("Fetched Appointments:", res.data); // Debugging line
      setAppointments(res.data);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      alert("Failed to load appointments.");
    }
  };

  useEffect(() => {
    if (!userId) {
      alert("Please login first!");
      navigate("/");
    } else {
      fetchAppointments();
    }
  }, [userId,navigate]); 

  const handleDelete = async (id) => {
    if (!id) return;
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      try {
        await axios.delete('http://localhost:5000/api/appointments/${id}');
        fetchAppointments();
      } catch (error) {
        console.error("Error deleting appointment:", error);
        alert("Failed to delete appointment.");
      }
    }
  };

  return (
    <div>
      <h2>My Appointments</h2>

      {appointments.length === 0 ? (
        <p>No appointments found.</p>
      ) : (
        <table border="1">
          <thead>
            <tr>
              <th>Provider</th>
              <th>Date/Time</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((appt) => (
              <tr key={appt.id}>
                <td>{appt.providerName}</td>
                <td>{appt.dateTime}</td>
                <td>{appt.reason}</td>
                <td>{appt.status}</td>
                <td>
                  <button onClick={() => handleDelete(appt.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button onClick={() => navigate("/add-appointment")}>Add Appointment</button>
    </div>
  );
}

export default Dashboard;