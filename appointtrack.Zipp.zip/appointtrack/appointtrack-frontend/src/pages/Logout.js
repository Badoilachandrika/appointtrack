import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.removeItem("token"); // Remove auth token
    alert("Logged out successfully!");
    navigate("/login"); // Redirect to login page
  }, []);

  return null; // No UI needed
};

export default Logout;