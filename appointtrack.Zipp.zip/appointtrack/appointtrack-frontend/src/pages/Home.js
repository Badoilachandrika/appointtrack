import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to AppointTrack</h1>
      <p>Manage your appointments easily.</p>
    </div>
  );
}

export default Home;