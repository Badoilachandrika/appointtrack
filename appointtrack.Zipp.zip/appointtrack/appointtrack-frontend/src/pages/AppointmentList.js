import React, { useEffect, useState } from 'react';
import { getAppointments } from './api';

const Appointments = () => {
    const [appointments, setAppointments] = useState([]);

    useEffect(() => {
        fetchAppointments();
    }, []);

    const fetchAppointments = async () => {
        const response = await getAppointments();
        setAppointments(response.data);
    };

    return (
        <div>
            <h2>Appointments</h2>
            <ul>
                {appointments.map((appt) => (
                    <li key={appt._id}>{appt.name} - {appt.date}</li>
                ))}
            </ul>
        </div>
    );
};

export default Appointments;
    