const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Appointment = sequelize.define("Appointment", {
  provider: { type: DataTypes.STRING, allowNull: false },
  date_time: { type: DataTypes.DATE, allowNull: false },
  reason: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.ENUM("Upcoming", "Completed", "Cancelled"), defaultValue: "Upcoming" },
});

module.exports = Appointment;